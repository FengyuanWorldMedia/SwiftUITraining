// Created by Manager on 2021/09/18.
// Copyright © 2021 Suzhou Fengyuan World Media. All rights reserved.
//
//  ContentView.swift
//  PodTest
//
//  Created by nnio on 2021/09/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
