// Created by Manager on 2021/09/18.
// Copyright © 2021 Suzhou Fengyuan World Media. All rights reserved.
public struct MyLibrary2 {
    var text = "Hello, World!2"
    public func printText() {
        print(text)
    }
}
