// Created by Manager on 2021/09/18.
// Copyright © 2021 Suzhou Fengyuan World Media. All rights reserved.
public struct MyLibrary {
    var text = "Hello, World!"
    public func printText() {
        print(text)
    }
}
