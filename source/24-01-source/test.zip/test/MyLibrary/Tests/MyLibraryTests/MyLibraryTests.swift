    // Created by Manager on 2021/09/18.
    // Copyright © 2021 Suzhou Fengyuan World Media. All rights reserved.
    import XCTest
    @testable import MyLibrary
    @testable import MyLibrary2
    
    final class MyLibraryTests: XCTestCase {
        func testExample() {
            // This is an example of a functional test case.
            // Use XCTAssert and related functions to verify your tests produce the correct
            // results.
            XCTAssertEqual(MyLibrary().text, "Hello, World!")
            MyLibrary().printText()
            MyLibrary2().printText()
        }
    }
